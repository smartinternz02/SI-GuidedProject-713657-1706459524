<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_VisitDate</name>
   <tag></tag>
   <elementGuidId>46fc49f1-29f3-4124-9275-0563c48d8381</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>visit_date</value>
   </webElementProperties>
</WebElementEntity>
