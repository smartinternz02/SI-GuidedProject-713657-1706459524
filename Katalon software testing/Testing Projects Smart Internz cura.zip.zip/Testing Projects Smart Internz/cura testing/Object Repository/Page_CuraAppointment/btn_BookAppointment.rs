<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_BookAppointment</name>
   <tag></tag>
   <elementGuidId>61c6be2b-37a2-4d86-980b-785e985fb89d</elementGuidId>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>btn-book-appointment</value>
   </webElementProperties>
</WebElementEntity>
